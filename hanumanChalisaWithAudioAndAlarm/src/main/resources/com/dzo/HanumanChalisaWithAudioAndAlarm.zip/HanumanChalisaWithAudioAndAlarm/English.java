package com.dzo.HanumanChalisaWithAudioAndAlarm;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.dzo.HanumanChalisaWithAudioAndAlarm.adapter.HanuDrawerListAdapter;
import com.dzo.HanumanChalisaWithAudioAndAlarm.dao.HanuDrawerItem;
import com.dzo.HanumanChalisaWithAudioAndAlarm.util.Prefs;

public class English extends BaseActivity {
	
	private ArrayList<HanuDrawerItem> mDrawerItem;
	private PagerWithPageControl mPager;
	 //MediaPlayer mp = null;
	 ImageButton btnPlaying, btn_Exit; 
	 String LOCALE_HINDI = "hi";
	 ImageButton btnHindi, btnEnglish, btnLogo;
	 boolean playerStarted, playerStoppedInOnStop;
	 BroadcastReceiver screenoffReceiver;
	 String LOCALE_ENGLISH = Locale.ENGLISH.toString();
	 TextView txtHome, txtEnglish, txtPlay, txtInfo, txtExit;
	 boolean chalisaPlaying = false;
	 boolean showOnce;
	 String SHOW_RATING_DIALOG = "showRatingDialog";
	 Intent in;
	 LinearLayout linHomebtn, linHindibtn, linEnglishbtn, linAudiobtn, linAboutbtn, linHindiToggle;
	 public static final String UPDATE_UI_ACTION = "com.dzo.HanumanChalisaWithAudioAndAlarm.UPDATE_UI";
	 /** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.hanu_reading_english);
		initView();
		
		Locale mLocale = new Locale(Locale.ENGLISH.toString());
		//Log.i("Hanuman Chalisa", ""+mLocale);
        Locale.setDefault(mLocale);
        Configuration config = new Configuration();
        config.locale = mLocale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
		
        //Log.i("Hanuman Chalisa default Locale", ""+Locale.getDefault());
		
		
		in = new Intent(English.this, ChalisaService.class);
		
		/*txtHome = (TextView)findViewById(R.id.txtHome);
		txtEnglish = (TextView)findViewById(R.id.txtEnglish);
		txtPlay = (TextView)findViewById(R.id.txtPlay);
		txtInfo = (TextView)findViewById(R.id.txtInfo);
		txtExit = (TextView)findViewById(R.id.txtExit);
		*/
//		txtEnglish.setTextColor(getResources().getColor(R.color.redwine));
	/*	linHindiToggle.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				SharedPreferences languagePrefs = getSharedPreferences(HanuAlarm.myPrefs, MODE_PRIVATE);
				
				if(Build.MANUFACTURER.equalsIgnoreCase("Samsung"))
				{
						Intent in = new Intent(English.this, StartManualActivity.class);
						startActivity(in);
						Log.i("Hanuman Chalisa Start Button", "Start Button Click event");
				}//if
				else
				{
					btnHindi.setClickable(false);
					Toast.makeText(English.this, 
							"Sorry, Devanagari Script is not supported by your device", Toast.LENGTH_SHORT).show();
					Log.i("Hanuman Chalisa StartManual Activity", "in else block");
				}//else
			}
		});*/
		
		/*btnHindi = (ImageButton)findViewById(R.id.btnHindi);
		
		if(Build.MANUFACTURER.equalsIgnoreCase("samsung"))
		{
			btnHindi.setVisibility(View.VISIBLE);
		}//if
		else
		{
			btnHindi.setVisibility(View.INVISIBLE);
		}//else
*/		
		/*btnEnglish = (ImageButton)findViewById(R.id.btnEnglish);
		txtPlay = (TextView)findViewById(R.id.txtPlay);
		btnPlaying = (ImageButton) findViewById(R.id.btnAudio);
		
		btn_Exit = (ImageButton)findViewById(R.id.btn_Exit);*/
		/*btn_Exit.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v) 
			{
				txtExit.setTextColor(getResources().getColor(R.color.redwine));
				showOnce = Prefs.getBoolean(English.this, SHOW_RATING_DIALOG);
				if(showOnce == false)
				{
					showDialog();
					Prefs.setBoolean(English.this, SHOW_RATING_DIALOG, true);
				}//if
				else
				{
					Intent in = new Intent(Intent.ACTION_MAIN);
					in.addCategory(Intent.CATEGORY_HOME);
					in.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(in);
					finish();
				}//else
			}//onClick
		});
		
		btnHindi.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(Build.MANUFACTURER.equalsIgnoreCase("Samsung"))
				{
						Intent in = new Intent(English.this, StartManualActivity.class);
						startActivity(in);
						//Log.i("Hanuman Chalisa Start Button", "Start Button Click event");
				}//if
				else
				{
					btnHindi.setClickable(false);
					Toast.makeText(English.this, 
							"Sorry, Devanagari Script is not supported by your device", Toast.LENGTH_SHORT).show();
					//Log.i("Hanuman Chalisa StartManual Activity", "in else block");
				}//else
			}//onClick
		});
		
		btnEnglish.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v) 
			{
				txtEnglish.setTextColor(getResources().getColor(R.color.redwine));
				Intent in = new Intent(English.this, English.class);
				startActivity(in);
			}
		});*/
		
		mPager = (PagerWithPageControl) findViewById(R.id.horizontal_pager);
        mPager.addPagerControl();
		
		/*mp = new MediaPlayer();
		mp = MediaPlayer.create(English.this, R.raw.chalisa);*/
		
		
		/*ImageButton start = (ImageButton) findViewById(R.id.btnHome);
		start.setOnClickListener(new OnClickListener() {
			public void onClick(View v) 
			{
				txtHome.setTextColor(getResources().getColor(R.color.redwine));
				Intent intent = new Intent(English.this, HanuAlarm.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		});	*/	
		 
		 
		 //btnPlaying.setBackgroundResource(R.drawable.btnplay);
		 //btnPlaying.setBackgroundResource(mp.isPlaying() ? R.drawable.btnpause : R.drawable.btnplay);
		 /*btnPlaying.setOnClickListener(new OnClickListener() {
	          public void onClick(View v) {
        	  
	        	// If !started, start & change the button	        	  
	        	  if(ChalisaService.playerFlag == 0)
					{
						startService(in);
						ChalisaService.playerFlag = 1;
						txtPlay.setText("Pause");
						txtPlay.setTextColor(getResources().getColor(R.color.redwine));
						btnPlaying.setBackgroundResource(R.drawable.btnpause);
					}//if
					else if(ChalisaService.playerFlag == 1)
					{
						ChalisaService.mediaPlayer.pause();
						ChalisaService.playerFlag = 0;
						txtPlay.setText("Play");
						txtPlay.setTextColor(getResources().getColor(R.color.white));
						btnPlaying.setBackgroundResource(R.drawable.btnplay_a);
					}//else
	          }
	      });*/
		 
		/* btnLogo = (ImageButton)findViewById(R.id.btnLogo);
		 btnLogo.setOnClickListener(new View.OnClickListener()
		 {
			
			public void onClick(View v)
			{
				txtInfo.setTextColor(getResources().getColor(R.color.redwine));
				Intent in = new Intent(English.this, About.class);
				startActivity(in);
			}
		});*/
		
	//	 registerReceiver(mUpdateUIReceiver, new IntentFilter(UPDATE_UI_ACTION));
	}
	
	
	

	   

	   
	  

	
	private void initView() {
		getActionBar().setBackgroundDrawable(
                getResources().getDrawable(R.drawable.header)); 
getLayoutInflater().inflate(R.layout.hanu_reading_english, frameLayout);
		
		/**
		 * Setting title and itemChecked  
		 */
		mDrawerList.setItemChecked(position, true);
		//setTitle(mDrawerMenuList[position]);
	}
	
		
	/*protected void onPause(){
	    super.onPause();		
	}
		
	protected void onStop() {
		super.onStop();
	}
		*/
		/**
		 * Override
		 * 
  		 * 2. If the player was not running and screen was off, do nothing. 
		 * 3. If the player was running and onPause Called making player off, we need to resume it. 
		 * 4. If the player was not running and onPause Called, do nothing. 
		 * 5. If the player was running and Screen was Off, on screen on (by any other process), stop the player.
		 */
		
		/*protected void onResume()
		{
			if(ChalisaService.playerFlag == 0)
			{
				txtPlay.setText("Play");
				txtPlay.setTextColor(getResources().getColor(R.color.white));
				btnPlaying.setBackgroundResource(R.drawable.btnplay_a);
				//Log.i("English", "onResume if");
			}//if
			else if(ChalisaService.playerFlag == 1)
			{
				
				txtPlay.setText("Pause");
				txtPlay.setTextColor(getResources().getColor(R.color.redwine));
				btnPlaying.setBackgroundResource(R.drawable.btnpause);
				//Log.i("English", "onResume else");
			}//else
			super.onResume();
	    }//onResume
*/		
		protected void onDestroy()
		{
			super.onDestroy();
		//	unregisterReceiver(mUpdateUIReceiver);
		}
		
	
		
		private void showDialog() 
		{
			AlertDialog.Builder ad = new AlertDialog.Builder(English.this);
			ad.setIcon(R.drawable.icon);
			ad.setTitle("Rate The App");
			ad.setMessage("Would you like to rate this app?");
			ad.setPositiveButton("Now", new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int which) 
				{
					Intent intent = new Intent(Intent.ACTION_VIEW); 
					intent.setData(Uri.parse("market://details?id="+getPackageName())); 
					try 
					{
					   startActivity(intent);
					}//try 
					catch (android.content.ActivityNotFoundException ex) 
					{
					      Toast.makeText(English.this, "Android Market Not Availbale at this Device", Toast.LENGTH_SHORT).show();
					}//catch
				}//onClick
			});
			
			ad.setNegativeButton("Later", new DialogInterface.OnClickListener() 
			{
				public void onClick(DialogInterface dialog, int which) 
				{
					Intent in = new Intent(Intent.ACTION_MAIN);
					in.addCategory(Intent.CATEGORY_HOME);
					in.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(in);
					finish();
				}//onClick
			});
			ad.show();
		}//showDialog
		
		/*private final BroadcastReceiver mUpdateUIReceiver = new BroadcastReceiver() 
	     {
	 		@Override
	 		public void onReceive(Context context, Intent intent) {
	 			//updateStatus();
	 			int playerFlagValue = intent.getIntExtra("Player_FLAG_VALUE", 0);
	 			if(playerFlagValue == 0)
	 			{
	 				txtPlay.setText("Play");
					txtPlay.setTextColor(getResources().getColor(R.color.white));
					btnPlaying.setBackgroundResource(R.drawable.music);
	 			}//if
	 			else
	 			{
	 				txtPlay.setText("Pause");
					txtPlay.setTextColor(getResources().getColor(R.color.redwine));
					btnPlaying.setBackgroundResource(R.drawable.pause);
	 			}//else
	 		}
	 	};*/
}
