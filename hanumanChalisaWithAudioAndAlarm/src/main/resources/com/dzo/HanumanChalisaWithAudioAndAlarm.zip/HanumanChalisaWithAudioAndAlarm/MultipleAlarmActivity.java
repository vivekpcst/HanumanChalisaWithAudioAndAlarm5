package com.dzo.HanumanChalisaWithAudioAndAlarm;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import com.dzo.HanumanChalisaWithAudioAndAlarm.adapter.AlarmTimeAdapter;
import com.dzo.HanumanChalisaWithAudioAndAlarm.dao.AlarmTimeDAO;
import com.dzo.HanumanChalisaWithAudioAndAlarm.database.AlarmDBHelper;

public class MultipleAlarmActivity extends ActionBarActivity implements OnItemClickListener
{
	ImageButton btnSetAlarm;
	static final int TIME_DIALOG_ID = 0;
	ListView listViewAlarmTime;
	public static final String AMPM = "AMPM";
	String strAmPM;
	int reqCode;
	AlarmDBHelper alarmDBHelper;
	boolean alarmEnabled;
	public static List<AlarmTimeDAO> alarmDAOList;
	Button btnBack;
	
	public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiple_alarm);
        alarmDBHelper = new AlarmDBHelper(MultipleAlarmActivity.this);
        alarmEnabled = getIntent().getBooleanExtra("ALARM_ENABLED", false);
        
        Log.v("HanumanChalisaMultipleAlarmActivity alarmEnabled", ""+alarmEnabled);
        
        alarmDAOList = alarmDBHelper.getAllAlarmTimeResults();
        Log.v("HanumanChalisaMultipleAlarmActivity alarmDaoList size: ", ""+alarmDAOList.size());
        
        listViewAlarmTime = (ListView)findViewById(R.id.listAlarmTime);
        getActionBar().setBackgroundDrawable(
                getResources().getDrawable(R.drawable.header)); 
        
       /* btnBack = (Button)findViewById(R.id.btnBack);*/
        
        if(alarmDAOList != null)
        {
        	AlarmTimeAdapter alarmAdapter = new AlarmTimeAdapter(MultipleAlarmActivity.this, 
    				alarmDAOList, alarmEnabled);
        	alarmAdapter.notifyDataSetChanged();
        	listViewAlarmTime.setAdapter(alarmAdapter);
        }//if
        
        /*btnBack.setOnClickListener(new View.OnClickListener() 
        {
			public void onClick(View v) 
			{
				Intent in = new Intent(MultipleAlarmActivity.this, HanuAlarm.class);
				startActivity(in);
				finish();
			}//onClick
		});*/
        
        btnSetAlarm = (ImageButton)findViewById(R.id.btnSetAlarm);
        btnSetAlarm.setOnClickListener(new View.OnClickListener()
        {
			public void onClick(View v) 
			{
				Intent setAlarmIntent = new Intent(MultipleAlarmActivity.this, SetAlarmActivity.class);
				setAlarmIntent.putExtra("FROM_CLASS", "MultipleAlarmActivity");
				startActivity(setAlarmIntent);
				finish();
				Log.v("HanumanChalisaMultipleAlarm btnSetTime", "onClick called");
			}//onClick
		});
        listViewAlarmTime.setOnItemClickListener(this);
        Log.v("HCMultipleAlarmActivity", "onCreate called");
    }//onCreate
	
	public void onBackPressed() 
	{
		/*Intent in = new Intent(MultipleAlarmActivity.this, English.class);
		startActivity(in);*/
		super.onBackPressed();
		finish();
		Log.v("HanumanChalisaMultipleAlarmActivity", "onbackpressed called");
	}//onBackPressed
	
    public void onItemClick(AdapterView<?> parent, View v, int pos, long id) 
	{
		handleClick(pos);
	}//onItemClick
    
    private void handleClick(int pos)
    {
		Intent alarmDetailIntent = new Intent(MultipleAlarmActivity.this, AlarmTimeDetail.class);
		alarmDetailIntent.putExtra("AlarmDAOToEdit", alarmDAOList.get(pos));
		alarmDetailIntent.putExtra("AlarmDAOPosition", pos);
		alarmDetailIntent.putExtra("ALARM_ENABLED", alarmEnabled);
		startActivity(alarmDetailIntent);
		finish();
	}//handleClick

    protected void onDestroy() 
    {
    	super.onDestroy();
    	if(alarmDBHelper != null)
    	{
    		alarmDBHelper.close();
    	}//if
    	Log.v("HanumanChalisaMultipleAlarmActivity", "onDestroy called");
    }//onDestroy
}//MultipleAlarmActivity
