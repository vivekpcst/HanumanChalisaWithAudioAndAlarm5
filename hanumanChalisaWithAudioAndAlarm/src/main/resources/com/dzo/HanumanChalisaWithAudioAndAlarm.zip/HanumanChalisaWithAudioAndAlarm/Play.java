package com.dzo.HanumanChalisaWithAudioAndAlarm;

import com.dzo.HanumanChalisaWithAudioAndAlarm.util.Apputils;
import com.dzo.HanumanChalisaWithAudioAndAlarm.util.Prefs;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Play extends BaseActivity {
	
	Button btnPlay;
	Intent	in ;
	int off=1;
	int on=0;
	int pause=2;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// set Layout
		//setContentView(R.layout.play);
		getActionBar().setBackgroundDrawable(
                getResources().getDrawable(R.drawable.header));
		
getLayoutInflater().inflate(R.layout.play, frameLayout);
		
		/**
		 * Setting title and itemChecked  
		 */
		mDrawerList.setItemChecked(position, true);
		//setTitle(mDrawerMenuList[position]);
		
		in = new Intent(Play.this, ChalisaService.class);

		btnPlay=(Button)findViewById(R.id.btnPlay);
		btnPlay.setOnClickListener(new OnClickListener() {
	          public void onClick(View v) {
	        	  
	        	  if((Prefs.getMusicOff(getApplicationContext(), Apputils.PAUSE_MUSIC))==pause)
	        	  {
	        		  ChalisaService.mediaPlayer.pause();
	        		  ChalisaService.playerFlag=0;
	        		  btnPlay.setBackgroundResource(R.drawable.music);
						Prefs.setMusicOff(getApplicationContext(),
								Apputils.PAUSE_MUSIC, 1);
	        	  }
      	  
	        	// If !started, start & change the button	        	  
	        	  else  if(ChalisaService.playerFlag == 0)
					{
						startService(in);
						ChalisaService.playerFlag = 1;
						Prefs.setMusicOff(getApplicationContext(),
								Apputils.PAUSE_MUSIC, 0);
						Log.i("Abhishek", "serviceoff");
						/*txtPlay.setText("Pause");
						txtPlay.setTextColor(getResources().getColor(R.color.redwine));*/
						btnPlay.setBackgroundResource(R.drawable.pause);
					}//if
					else if(ChalisaService.playerFlag == 1)
					{
						ChalisaService.mediaPlayer.pause();
						ChalisaService.playerFlag = 0;
						btnPlay.setBackgroundResource(R.drawable.music);
						Prefs.setMusicOff(getApplicationContext(),
								Apputils.PAUSE_MUSIC, 1);
						Log.i("Verma", "serviceOn");
//						txtPlay.setText("Play");
//						txtPlay.setTextColor(getResources().getColor(R.color.white));
						
					}//else
	          }
	      });

}
	
	protected void onPause(){
	    super.onPause();
	    
	}
		
	protected void onStop() {
		super.onStop();
		Log.e("Abhishek", "OnstopCalled");
		
	}
		
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}
		/**
		 * Override
		 * 
  		 * 2. If the player was not running and screen was off, do nothing. 
		 * 3. If the player was running and onPause Called making player off, we need to resume it. 
		 * 4. If the player was not running and onPause Called, do nothing. 
		 * 5. If the player was running and Screen was Off, on screen on (by any other process), stop the player.
		 */
		
		protected void onResume()
		{
			Log.i("English", "onResume");
			super.onResume();
		if(ChalisaService.playerFlag == 0)
			{
			if((Prefs.getMusicOff(getApplicationContext(), Apputils.PAUSE_MUSIC))==off)
			{
				btnPlay.setBackgroundResource(R.drawable.music);
				ChalisaService.playerFlag = 0;
				Log.i("English", "onResume if");
			}
				
				
			}//if
			else if(ChalisaService.playerFlag == 1)
			{
				if((Prefs.getMusicOff(getApplicationContext(), Apputils.PLAY_MUSIC))==on)
				{
					Log.i("English", "onResume else");
					btnPlay.setBackgroundResource(R.drawable.pause);
					ChalisaService.playerFlag = 1;
					
				}
				
				
			}//else			super.onResume();
	    }//onResume
		
		/*protected void onDestroy()
		{
			super.onDestroy();
			unregisterReceiver(mUpdateUIReceiver);
		}*/
		private final BroadcastReceiver mUpdateUIReceiver = new BroadcastReceiver() 
	     {
			@Override
	 		public void onReceive(Context context, Intent intent) 
	    	{
	 			int playerFlagValue = intent.getIntExtra("Player_FLAG_VALUE", 0);
	 			if(playerFlagValue == 0)
	 			{
	 				/*txtPlay.setText("Play");
					txtPlay.setTextColor(getResources().getColor(R.color.white));*/
					btnPlay.setBackgroundResource(R.drawable.music);
	 			}//if
	 			else
	 			{
	 				/*txtPlay.setText("Pause");
					txtPlay.setTextColor(getResources().getColor(R.color.redwine));
*/					btnPlay.setBackgroundResource(R.drawable.pause);
	 			}//else
	 		}
	 	};
}
