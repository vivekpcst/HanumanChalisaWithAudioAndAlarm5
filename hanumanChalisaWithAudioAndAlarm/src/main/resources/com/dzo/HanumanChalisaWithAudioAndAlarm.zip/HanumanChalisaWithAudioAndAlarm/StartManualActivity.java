package com.dzo.HanumanChalisaWithAudioAndAlarm;


import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dzo.HanumanChalisaWithAudioAndAlarm.util.Prefs;

public class StartManualActivity extends BaseActivity {

	private PagerWithPageControl mPager;
	 static ImageButton btnPlaying, btnHindi, btnEnglish, btnLogo; 
	 LinearLayout linHomebtn, linHindibtn, linEnglishbtn, linAudiobtn, linAboutbtn, linEnglishToggle;
	 String LOCALE_HINDI = "hi";
	 String LOCALE_ENGLISH = Locale.ENGLISH.toString();
	 TextView txtHome, txtHindi, txtPlay, txtinfo, txtExit;
	 Intent in;
	 Locale mLocale, defaultLocale;
	 Configuration config;
	 ImageButton btnLang, btn_Exit;
	 boolean playerStarted, playerStoppedInOnStop;
	 BroadcastReceiver screenoffReceiver;
	 String myPref;
	 static SharedPreferences languagePref;
	 //boolean chalisaPlaying = false;
	 String SHOW_RATING_DIALOG = "showRatingDialog";
	 boolean showOnce;
	 public static final String UPDATE_UI_ACTION = "com.dzo.HanumanChalisaWithAudioAndAlarm.UPDATE_UI";
	 
	 public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		mLocale = new Locale(HanuAlarm.LOCALE_HINDI);
		//Log.i("Hanuman Chalisa", ""+mLocale);
        Locale.setDefault(mLocale);
        config = new Configuration();
        config.locale = mLocale;
       getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics()); 
        
		//Log.i("Hanuman Chalisa default Locale", ""+Locale.getDefault());
		//setContentView(R.layout.hanu_reading_hindi);
		
getLayoutInflater().inflate(R.layout.hanu_reading_hindi, frameLayout);
		
		/**
		 * Setting title and itemChecked  
		 */
		mDrawerList.setItemChecked(position, true);
		//setTitle(mDrawerMenuList[position]);

		getActionBar().setBackgroundDrawable(
                getResources().getDrawable(R.drawable.header)); 
		
	//	in = new Intent(StartManualActivity.this, ChalisaService.class);
		
		/*txtHome = (TextView)findViewById(R.id.txtHome);
		txtHindi = (TextView)findViewById(R.id.txtHindi);
		txtPlay = (TextView)findViewById(R.id.txtPlay);
		txtinfo = (TextView)findViewById(R.id.txtInfo);
		txtExit = (TextView)findViewById(R.id.txtExit);*/
		
		/*txtHindi.setTextColor(getResources().getColor(R.color.redwine));
		btnHindi = (ImageButton)findViewById(R.id.btnHindi);
		
		btnHindi.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				txtHindi.setTextColor(getResources().getColor(R.color.redwine));
				if(Build.MANUFACTURER.equalsIgnoreCase("Samsung"))
				{
					Intent in = new Intent(StartManualActivity.this, StartManualActivity.class);
					startActivity(in);
					//Log.i("Hanuman Chalisa Start Button", "Start Button Click event");
				}//if
				else
				{
					btnHindi.setClickable(false);
					Toast.makeText(StartManualActivity.this, 
							"Sorry, Devanagari Script is not supported by your device", Toast.LENGTH_SHORT).show();
					//Log.i("Hanuman Chalisa StartManual Activity", "in else block");
				}//else
			}//onClick
		});*/
		
		/*btnEnglish = (ImageButton)findViewById(R.id.btnEnglish);
		
		if(Build.MANUFACTURER.equalsIgnoreCase("samsung"))
		{
			btnEnglish.setVisibility(View.VISIBLE);
		}//if
		else
		{
			btnEnglish.setVisibility(View.INVISIBLE);
		}//else
*/		/*btnEnglish.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				Intent in = new Intent(StartManualActivity.this, English.class);
				startActivity(in);
			}//else
		});*/
		mPager = (PagerWithPageControl) findViewById(R.id.horizontal_pager);
        mPager.addPagerControl();
		
	/*	mp = new MediaPlayer();
		mp = MediaPlayer.create(StartManualActivity.this, R.raw.chalisa);*/
		
		
		/*ImageButton start = (ImageButton) findViewById(R.id.btnHome);
		start.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				txtHome.setTextColor(getResources().getColor(R.color.redwine));
				languagePref = getSharedPreferences(HanuAlarm.myPrefs, MODE_PRIVATE);
				
				Editor e = languagePref.edit();
				e.putString(HanuAlarm.prefHindi, HanuAlarm.LOCALE_HINDI);
				e.commit();
				
				Intent intent = new Intent(StartManualActivity.this, HanuAlarm.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		});	*/
		
		/*btnLogo = (ImageButton)findViewById(R.id.btnLogo);
		btnLogo.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				txtinfo.setTextColor(getResources().getColor(R.color.redwine));
				Intent in = new Intent(StartManualActivity.this, About.class);
				startActivity(in);
			}
		});*/
		 
		/* btnPlaying = (ImageButton) findViewById(R.id.btnAudio);
		 //btnPlaying.setBackgroundResource(R.drawable.btnplay);
		 //btnPlaying.setBackgroundResource(mp.isPlaying() ? R.drawable.btnpause : R.drawable.btnplay);
		 btnPlaying.setOnClickListener(new OnClickListener() {
	          public void onClick(View v) {
        	  
	        	  // If !started, start & change the button	        	  
	        	  if(ChalisaService.playerFlag == 0)
					{
						startService(in);
						ChalisaService.playerFlag = 1;
						//Log.i("HanuAlarm play button if", ""+HanuAlarm.chalisaPlaying);
						txtPlay.setText("Pause");
						txtPlay.setTextColor(getResources().getColor(R.color.redwine));
						btnPlaying.setBackgroundResource(R.drawable.btnpause);
					}//if
					else if(ChalisaService.playerFlag == 1)
					{
						ChalisaService.mediaPlayer.pause();
						ChalisaService.playerFlag = 0;
						//Log.i("HanuAlarm play button else", ""+HanuAlarm.chalisaPlaying);
						txtPlay.setText("Play");
						txtPlay.setTextColor(getResources().getColor(R.color.white));
						btnPlaying.setBackgroundResource(R.drawable.btnplay_a);
					}//else
	          }
	      });*/
		 
		 /*btn_Exit = (ImageButton)findViewById(R.id.btn_Exit);
		 
		 btn_Exit.setOnClickListener(new View.OnClickListener()
		 {
			public void onClick(View v) 
			{
				txtExit.setTextColor(getResources().getColor(R.color.redwine));
				showOnce = Prefs.getBoolean(StartManualActivity.this, SHOW_RATING_DIALOG);
				if(showOnce == false)
				{
					showDialog();
					Prefs.setBoolean(StartManualActivity.this, SHOW_RATING_DIALOG, true);
				}//if
				else
				{
					Intent in = new Intent(Intent.ACTION_MAIN);
					in.addCategory(Intent.CATEGORY_HOME);
					in.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(in);
					finish();
				}//else
			}
		});
		 */
		registerReceiver(mUpdateUIReceiver, new IntentFilter(UPDATE_UI_ACTION));
	}	
		
		
		protected void onPause(){
	    	super.onPause();
		}
		
	protected void onStop() {
		super.onStop();
	}
		
		protected void onResume()
		{
			super.onResume();
			/*if(ChalisaService.playerFlag == 0)
	    	{	
				txtPlay.setText("Play");
	    		txtPlay.setTextColor(getResources().getColor(R.color.white));
				btnPlaying.setBackgroundResource(R.drawable.btnplay_a);
				//Log.i("Hindi", "onResume if");
	    	}
	    	else if(ChalisaService.playerFlag == 1)
	    	{
	    		txtPlay.setText("Pause");
	    		txtPlay.setTextColor(getResources().getColor(R.color.redwine));
	    		btnPlaying.setBackgroundResource(R.drawable.btnpause);
				//Log.i("Hindi", "onResume else");
	    	}*/
	    }
		
		protected void onDestroy()
		{
			super.onDestroy();
			unregisterReceiver(mUpdateUIReceiver);
		}
		
		@Override
		public void onBackPressed() {
			// TODO Auto-generated method stub
			super.onBackPressed();
		}
		
		@Override
		protected void onRestart() 
		{
			super.onRestart();
		}
		
		private void showDialog() 
		 {
				AlertDialog.Builder ad = new AlertDialog.Builder(StartManualActivity.this);
				ad.setIcon(R.drawable.icon);
				ad.setTitle("Rate The App");
				ad.setMessage("Would you like to rate this app?");
				ad.setPositiveButton("Now", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int which) 
					{
						Intent intent = new Intent(Intent.ACTION_VIEW); 
						intent.setData(Uri.parse("market://details?id="+getPackageName())); 
						try 
						{
						   startActivity(intent);
						}//try 
						catch (android.content.ActivityNotFoundException ex) 
						{
						      Toast.makeText(StartManualActivity.this, "Android Market Not Availbale at this Device", Toast.LENGTH_SHORT).show();
						}//catch
					}//onClick
				});
				
				ad.setNegativeButton("Later", new DialogInterface.OnClickListener() 
				{
					public void onClick(DialogInterface dialog, int which) 
					{
						Intent in = new Intent(Intent.ACTION_MAIN);
						in.addCategory(Intent.CATEGORY_HOME);
						in.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(in);
						finish();
					}//onClick
				});
				ad.show();
			}//showDialog
		
		private final BroadcastReceiver mUpdateUIReceiver = new BroadcastReceiver() 
	    {
	 		@Override
	 		public void onReceive(Context context, Intent intent) {
	 			//updateStatus();
	 			int playerFlagValue = intent.getIntExtra("Player_FLAG_VALUE", 0);
	 			if(playerFlagValue == 0)
	 			{
	 				txtPlay.setText("Play");
					txtPlay.setTextColor(getResources().getColor(R.color.white));
					btnPlaying.setBackgroundResource(R.drawable.play);
	 			}//if
	 			else
	 			{
	 				txtPlay.setText("Pause");
					txtPlay.setTextColor(getResources().getColor(R.color.redwine));
					btnPlaying.setBackgroundResource(R.drawable.btnpause);
	 			}//else
	 		}
	 	};
		
}
