/**
 * Nitish 10 Dec, 2012
 * 
 * This broadcastreceiver will be called after the device 
 * reboots for resetting alarm
 * */
package com.dzo.HanumanChalisaWithAudioAndAlarm.receiver;

import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.dzo.HanumanChalisaWithAudioAndAlarm.dao.AlarmTimeDAO;
import com.dzo.HanumanChalisaWithAudioAndAlarm.database.AlarmDBHelper;
import com.dzo.HanumanChalisaWithAudioAndAlarm.util.SetAlarmOnReboot;

public class BootCompleteReceiver extends BroadcastReceiver 
{
	AlarmDBHelper alarmHelper;
    List<AlarmTimeDAO> mAlarmList;
    int mAlarmHour = 0, mAlarmMin = 0;
    boolean alarmEnabled;
    
	public void onReceive(Context context, Intent intent) 
	{
		alarmHelper = new AlarmDBHelper(context);
    	mAlarmList = alarmHelper.getAllAlarmTimeResults();
    	
    	
    	if((mAlarmList == null) || (mAlarmList.size() == 0))
    	{
    		Log.v("HCBootCompleteReceiver onReceiver", "no data found");
    	}//if
    	else
    	{
    		for(int i = 0; i < mAlarmList.size(); i++)
    		{
    			AlarmTimeDAO alarmTimeDAO = mAlarmList.get(i);
    			int alarmId = alarmTimeDAO.getId();
    			String alarmTime = alarmTimeDAO.getAlarmTime();
    			String daysToRepeatAlarm = alarmTimeDAO.getDaysToRepeatAlarm();
    			String sundayRepeatId = alarmTimeDAO.getSundayRepeatId();
    			String mondayRepeatId = alarmTimeDAO.getMondayRepeatId();
    			String tuesdayRepeatId = alarmTimeDAO.getTuesdayRepeatId();
    			String wednesdayRepeatId = alarmTimeDAO.getWednesdayRepeatId();
    			String thursdayRepeatId = alarmTimeDAO.getThursdayRepeatId();
    			String fridayRepeatId = alarmTimeDAO.getFridayRepeatId();
    			String saturdayRepeatId = alarmTimeDAO.getSaturdayRepeatId();
    			SetAlarmOnReboot setAlarmOnReboot = new SetAlarmOnReboot(context);
  
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Daily"))
    			{
    				setAlarmOnReboot.setDailyAlarmAfterReboot(alarmId, alarmTime, 
    						daysToRepeatAlarm);
    				Log.v("HCBootCompleteReceiver", "daily alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Sunday"))
    			{
    				setAlarmOnReboot.setSundayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, sundayRepeatId);
    				Log.v("HCBootCompleteReceiver", "sunday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Monday"))
    			{
    				setAlarmOnReboot.setMondayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, mondayRepeatId);
    				Log.v("HCBootCompleteReceiver", "monday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Tuesday"))
    			{
    				setAlarmOnReboot.setTuesdayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, tuesdayRepeatId);
    				Log.v("HCBootCompleteReceiver", "tuesday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Wednesday"))
    			{
    				setAlarmOnReboot.setWednesdayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, wednesdayRepeatId);
    				Log.v("HCBootCompleteReceiver", "wednesday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Thursday"))
    			{
    				setAlarmOnReboot.setThursdayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, thursdayRepeatId);
    				Log.v("HCBootCompleteReceiver", "thursday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Friday"))
    			{
    				setAlarmOnReboot.setFridayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, fridayRepeatId);
    				Log.v("HCBootCompleteReceiver", "friday alarm set on reboot");
    			}//if
    			
    			if(alarmTimeDAO.getDaysToRepeatAlarm().contains("Saturday"))
    			{
    				setAlarmOnReboot.setSaturdayAlarmAfterReboot(alarmTime, 
    						daysToRepeatAlarm, saturdayRepeatId);
    				Log.v("HCBootCompleteReceiver", "saturday alarm set on reboot");
    			}//if
    			Log.v("HCBootCompleteReceiver", "mAlarmList not null in for loop");
    		}//for
    		Log.v("HCBootCompleteReceiver", "mAlarmList not null");
    	}//else
    	Log.v("HCBootCompleteReceiver", "onReceive called");
	}//onReceive	
}//BootCompleteReceiver
