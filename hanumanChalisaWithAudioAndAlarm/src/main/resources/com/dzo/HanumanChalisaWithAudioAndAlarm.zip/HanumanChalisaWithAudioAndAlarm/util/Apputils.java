package com.dzo.HanumanChalisaWithAudioAndAlarm.util;

public class Apputils {
	
	public static final String GCM_DEVICE_REG_ID = "gcmDeviceRegistrationID";
	public static final String PROPERTY_APP_VERSION = "appVersion";
	public static final String GCM_SENDER_ID = "817622461279";
	public static final String PAUSE_MUSIC="pausemusic";
	public static final String PLAY_MUSIC="playmusic";
}
